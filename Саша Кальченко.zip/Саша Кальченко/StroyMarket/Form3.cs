using System.Net.Mail;
using System.Text.RegularExpressions;

namespace StroyMarket;

public partial class Form3 : Form
{
    private long _selectedId;
    private bool _updating;

    public Form3()
    {
        InitializeComponent();
        if (System.ComponentModel.LicenseManager.UsageMode == System.ComponentModel.LicenseUsageMode.Designtime) return;
        cmbCustomerType.SelectedIndex = 0;
        RefreshCustomers();
    }

    private void RefreshCustomers()
    {
        try
        {
            var all = StoreDatabase.GetCustomers();
            var filter = txtCustomerSearch.Text.Trim();
            var rows = all.Where(c => filter.Length == 0 ||
                c.FullName.Contains(filter, StringComparison.CurrentCultureIgnoreCase) ||
                c.Phone.Contains(filter, StringComparison.OrdinalIgnoreCase)).ToList();
            _updating = true;
            try
            {
                dgvCustomers.Rows.Clear();
                foreach (var customer in rows)
                {
                    var index = dgvCustomers.Rows.Add(customer.FullName, customer.Phone, customer.Type);
                    dgvCustomers.Rows[index].Tag = customer;
                }
                dgvCustomers.ClearSelection();
            }
            finally
            {
                _updating = false;
            }
            lblCustomerCount.Text = $"Клиентов: {rows.Count} из {all.Count}";
            lblStatus.Text = "Карточки загружены из базы данных.";
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void txtCustomerSearch_TextChanged(object? sender, EventArgs e) => RefreshCustomers();

    private void btnResetSearch_Click(object? sender, EventArgs e)
    {
        txtCustomerSearch.Clear();
        RefreshCustomers();
    }

    private void dgvCustomers_SelectionChanged(object? sender, EventArgs e)
    {
        if (_updating || dgvCustomers.SelectedRows.Count == 0) return;
        if (dgvCustomers.SelectedRows[0].Tag is not Customer customer) return;
        _selectedId = customer.Id;
        txtLastName.Text = customer.LastName;
        txtFirstName.Text = customer.FirstName;
        txtMiddleName.Text = customer.MiddleName;
        txtPhone.Text = customer.Phone;
        txtEmail.Text = customer.Email;
        if (!cmbCustomerType.Items.Contains(customer.Type)) cmbCustomerType.Items.Add(customer.Type);
        cmbCustomerType.SelectedItem = customer.Type;
        txtAddress.Text = customer.Address;
        nudDiscount.Value = Math.Clamp(customer.Discount, 0, 100);
        txtNotes.Text = customer.Notes;
    }

    private void btnCustomerNew_Click(object? sender, EventArgs e)
    {
        _selectedId = 0;
        dgvCustomers.ClearSelection();
        txtLastName.Clear();
        txtFirstName.Clear();
        txtMiddleName.Clear();
        txtPhone.Clear();
        txtEmail.Clear();
        cmbCustomerType.SelectedIndex = 0;
        txtAddress.Clear();
        nudDiscount.Value = 0;
        txtNotes.Clear();
        txtLastName.Focus();
        lblStatus.Text = "Новая карточка клиента. Заполните обязательные поля.";
    }

    private void btnCustomerSave_Click(object? sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtLastName.Text) || string.IsNullOrWhiteSpace(txtFirstName.Text))
        {
            MessageBox.Show("Укажите фамилию и имя клиента.", "Проверка", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        var phone = txtPhone.Text.Trim();
        if (!Regex.IsMatch(phone, @"^\+?[0-9\s\(\)\-]{7,23}$") || phone.Count(char.IsDigit) < 10)
        {
            MessageBox.Show("Укажите корректный номер телефона.", "Проверка", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        if (!string.IsNullOrWhiteSpace(txtEmail.Text) && !MailAddress.TryCreate(txtEmail.Text.Trim(), out _))
        {
            MessageBox.Show("Проверьте адрес электронной почты.", "Проверка", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        var customer = new Customer
        {
            Id = _selectedId,
            LastName = txtLastName.Text.Trim(),
            FirstName = txtFirstName.Text.Trim(),
            MiddleName = txtMiddleName.Text.Trim(),
            Phone = phone,
            Email = txtEmail.Text.Trim(),
            Type = cmbCustomerType.SelectedItem?.ToString() ?? "Розничный",
            Address = txtAddress.Text.Trim(),
            Discount = (int)nudDiscount.Value,
            Notes = txtNotes.Text.Trim()
        };
        try
        {
            StoreDatabase.SaveCustomer(customer);
            btnCustomerNew_Click(sender, EventArgs.Empty);
            RefreshCustomers();
            lblStatus.Text = $"Сохранена карточка: {customer.FullName}";
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void btnCustomerDelete_Click(object? sender, EventArgs e)
    {
        if (_selectedId == 0)
        {
            MessageBox.Show("Сначала выберите клиента в таблице.", "Удаление", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        if (MessageBox.Show("Удалить выбранную карточку клиента?", "Подтверждение",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        try
        {
            StoreDatabase.RemoveCustomer(_selectedId);
            btnCustomerNew_Click(sender, EventArgs.Empty);
            RefreshCustomers();
            lblStatus.Text = "Карточка клиента удалена.";
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void btnStockNav_Click(object? sender, EventArgs e) => Close();

    private void ShowError(Exception exception)
    {
        MessageBox.Show(exception.Message, "Строй Маркет", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}
