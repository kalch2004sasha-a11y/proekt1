namespace StroyMarket;

public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
        AcceptButton = btnLogin;
        CancelButton = btnExit;
        txtLogin.Focus();
    }

    private void chkPassword_CheckedChanged(object? sender, EventArgs e)
    {
        txtPassword.UseSystemPasswordChar = !chkPassword.Checked;
    }

    private void btnLogin_Click(object? sender, EventArgs e)
    {
        var login = txtLogin.Text.Trim();
        var password = txtPassword.Text;
        if (login.Length == 0 || password.Length == 0)
        {
            MessageBox.Show("Введите логин и пароль.", "Авторизация", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        try
        {
            if (!StoreDatabase.VerifyCredentials(login, password))
            {
                txtPassword.Clear();
                MessageBox.Show("Неверный логин или пароль.", "Ошибка входа", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPassword.Focus();
                return;
            }

            Hide();
            try
            {
                using var warehouse = new Form2();
                warehouse.ShowDialog();
            }
            finally
            {
                txtPassword.Clear();
                chkPassword.Checked = false;
                Show();
                txtPassword.Focus();
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка при входе: {ex.Message}", "Строй Маркет", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void btnExit_Click(object? sender, EventArgs e) => Close();
}
