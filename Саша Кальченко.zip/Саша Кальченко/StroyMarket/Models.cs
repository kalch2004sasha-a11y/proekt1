namespace StroyMarket;

public sealed class Product
{
    public long Id { get; set; }
    public string Sku { get; set; } = "";
    public string Name { get; set; } = "";
    public string Category { get; set; } = "";
    public string Unit { get; set; } = "";
    public long PriceKopecks { get; set; }
    public int Quantity { get; set; }
    public int MinimumQuantity { get; set; }
    public string Supplier { get; set; } = "";
}

public sealed class Customer
{
    public long Id { get; set; }
    public string LastName { get; set; } = "";
    public string FirstName { get; set; } = "";
    public string MiddleName { get; set; } = "";
    public string Phone { get; set; } = "";
    public string Email { get; set; } = "";
    public string Type { get; set; } = "Розничный";
    public string Address { get; set; } = "";
    public int Discount { get; set; }
    public string Notes { get; set; } = "";

    public string FullName => string.Join(" ", new[] { LastName, FirstName, MiddleName }.Where(s => !string.IsNullOrWhiteSpace(s)));
}
