namespace StroyMarket;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        try
        {
            StoreDatabase.Initialize();
            Application.Run(new Form1());
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Не удалось запустить приложение.\n{ex.Message}", "Строй Маркет", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
