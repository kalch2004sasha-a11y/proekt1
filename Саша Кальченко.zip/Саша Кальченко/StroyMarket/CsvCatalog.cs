using System.Globalization;
using System.Text;

namespace StroyMarket;

internal static class CsvCatalog
{
    private static readonly string[] Columns = { "Артикул", "Наименование", "Категория", "Единица", "Цена", "Количество", "Мин.остаток", "Поставщик" };

    public static List<Product> Read(string path)
    {
        var text = File.ReadAllText(path, Encoding.UTF8);
        var first = text.Split('\n', 2)[0];
        var delimiter = first.Count(c => c == ';') >= first.Count(c => c == ',') ? ';' : ',';
        var rows = Parse(text, delimiter).Where(r => r.Any(v => !string.IsNullOrWhiteSpace(v))).ToList();
        if (rows.Count < 2) throw new FormatException("Файл не содержит строк с товарами.");
        var header = rows[0].Select(s => s.Trim().TrimStart('\uFEFF')).ToArray();
        if (header.Length != Columns.Length || !Columns.SequenceEqual(header, StringComparer.OrdinalIgnoreCase))
            throw new FormatException("Заголовки CSV должны совпадать с шаблоном из папки Samples.");
        var result = new List<Product>();
        for (var i = 1; i < rows.Count; i++)
        {
            var row = rows[i];
            if (row.Length != Columns.Length) throw new FormatException($"Строка {i + 1}: ожидалось 8 значений.");
            var priceRaw = row[4].Replace(" ", "").Replace(',', '.');
            if (!decimal.TryParse(priceRaw, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out var price) || price < 0 || price > 100000000m)
                throw new FormatException($"Строка {i + 1}: неверная цена.");
            if (!int.TryParse(row[5], out var quantity) || quantity < 0 || !int.TryParse(row[6], out var minimum) || minimum < 0)
                throw new FormatException($"Строка {i + 1}: неверное количество или минимальный остаток.");
            if (string.IsNullOrWhiteSpace(row[0]) || string.IsNullOrWhiteSpace(row[1]) || string.IsNullOrWhiteSpace(row[2]) || string.IsNullOrWhiteSpace(row[3]))
                throw new FormatException($"Строка {i + 1}: заполните обязательные поля.");
            result.Add(new Product
            {
                Sku = row[0].Trim(), Name = row[1].Trim(), Category = row[2].Trim(),
                Unit = row[3].Trim(), PriceKopecks = checked((long)decimal.Round(price * 100, 0, MidpointRounding.AwayFromZero)),
                Quantity = quantity, MinimumQuantity = minimum, Supplier = row[7].Trim()
            });
        }
        if (result.Select(x => x.Sku).Distinct(StringComparer.OrdinalIgnoreCase).Count() != result.Count)
            throw new FormatException("В CSV есть повторяющиеся артикулы.");
        return result;
    }

    public static void Write(string path, IEnumerable<Product> products)
    {
        using var writer = new StreamWriter(path, false, new UTF8Encoding(true));
        writer.WriteLine(string.Join(';', Columns));
        foreach (var p in products)
        {
            var cells = new[]
            {
                p.Sku, p.Name, p.Category, p.Unit,
                (p.PriceKopecks / 100m).ToString("0.00", CultureInfo.InvariantCulture),
                p.Quantity.ToString(), p.MinimumQuantity.ToString(), p.Supplier
            };
            writer.WriteLine(string.Join(';', cells.Select(v => Escape(v))));
        }
    }

    private static string Escape(string value)
    {
        if (value.Contains(';') || value.Contains('"') || value.Contains('\n') || value.Contains('\r'))
            return "\"" + value.Replace("\"", "\"\"") + "\"";
        return value;
    }

    private static IEnumerable<string[]> Parse(string data, char delimiter)
    {
        var row = new List<string>();
        var field = new StringBuilder();
        var quoted = false;
        for (var i = 0; i < data.Length; i++)
        {
            var c = data[i];
            if (c == '"')
            {
                if (quoted && i + 1 < data.Length && data[i + 1] == '"')
                {
                    field.Append('"');
                    i++;
                }
                else quoted = !quoted;
            }
            else if (!quoted && c == delimiter)
            {
                row.Add(field.ToString());
                field.Clear();
            }
            else if (!quoted && (c == '\n' || c == '\r'))
            {
                if (c == '\r' && i + 1 < data.Length && data[i + 1] == '\n') i++;
                row.Add(field.ToString());
                field.Clear();
                yield return row.ToArray();
                row.Clear();
            }
            else field.Append(c);
        }
        if (quoted) throw new FormatException("Ошибка CSV: незакрытые кавычки.");
        if (field.Length > 0 || row.Count > 0)
        {
            row.Add(field.ToString());
            yield return row.ToArray();
        }
    }
}
