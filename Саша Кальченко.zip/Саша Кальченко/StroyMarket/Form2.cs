using System.Globalization;
using Microsoft.Data.Sqlite;

namespace StroyMarket;

public partial class Form2 : Form
{
    private long _selectedId;
    private bool _updating;
    private static readonly CultureInfo MoneyCulture = CultureInfo.GetCultureInfo("ru-RU");

    public Form2()
    {
        InitializeComponent();
        if (System.ComponentModel.LicenseManager.UsageMode == System.ComponentModel.LicenseUsageMode.Designtime) return;
        cmbFilter.SelectedIndex = 0;
        cmbCategory.SelectedIndex = 0;
        cmbUnit.SelectedIndex = 0;
        dgvProducts.ClearSelection();
        RefreshProducts();
    }

    private void RefreshProducts()
    {
        try
        {
            var all = StoreDatabase.GetProducts();
            var totalValue = all.Sum(x => (decimal)x.PriceKopecks * x.Quantity) / 100m;
            lblTotal.Text = all.Count.ToString("N0", MoneyCulture);
            lblAmount.Text = totalValue.ToString("N2", MoneyCulture) + " ₽";
            lblLow.Text = all.Count(x => x.Quantity <= x.MinimumQuantity).ToString("N0", MoneyCulture);

            foreach (var category in all.Select(x => x.Category).Distinct().OrderBy(x => x))
            {
                if (!cmbCategory.Items.Contains(category)) cmbCategory.Items.Add(category);
                if (!cmbFilter.Items.Contains(category)) cmbFilter.Items.Add(category);
            }

            var search = txtSearch.Text.Trim();
            var categoryFilter = cmbFilter.SelectedItem?.ToString() ?? "Все категории";
            var rows = all.Where(p =>
                (search.Length == 0 || p.Sku.Contains(search, StringComparison.CurrentCultureIgnoreCase)
                || p.Name.Contains(search, StringComparison.CurrentCultureIgnoreCase)
                || p.Supplier.Contains(search, StringComparison.CurrentCultureIgnoreCase))
                && (categoryFilter == "Все категории" || p.Category == categoryFilter)).ToList();

            _updating = true;
            try
            {
                dgvProducts.Rows.Clear();
                foreach (var p in rows)
                {
                    var index = dgvProducts.Rows.Add(p.Sku, p.Name, p.Category, p.Unit,
                        (p.PriceKopecks / 100m).ToString("N2", MoneyCulture), p.Quantity, p.MinimumQuantity);
                    dgvProducts.Rows[index].Tag = p;
                    if (p.Quantity <= p.MinimumQuantity)
                        dgvProducts.Rows[index].DefaultCellStyle.BackColor = Color.FromArgb(255, 241, 230);
                }
                dgvProducts.ClearSelection();
            }
            finally
            {
                _updating = false;
            }
            lblStatus.Text = $"Показано {rows.Count} из {all.Count} позиций. Оранжевым отмечены товары с низким остатком.";
        }
        catch (Exception ex)
        {
            ShowError(ex);
        }
    }

    private void Filters_Changed(object? sender, EventArgs e)
    {
        RefreshProducts();
    }

    private void dgvProducts_SelectionChanged(object? sender, EventArgs e)
    {
        if (_updating || dgvProducts.SelectedRows.Count == 0) return;
        if (dgvProducts.SelectedRows[0].Tag is not Product product) return;

        _selectedId = product.Id;
        txtSku.Text = product.Sku;
        txtProductName.Text = product.Name;
        cmbCategory.SelectedItem = product.Category;
        cmbUnit.SelectedItem = product.Unit;
        if (cmbUnit.SelectedIndex == -1) cmbUnit.Items.Add(product.Unit);
        cmbUnit.SelectedItem = product.Unit;
        nudPrice.Value = Math.Min(nudPrice.Maximum, product.PriceKopecks / 100m);
        nudQuantity.Value = Math.Min(nudQuantity.Maximum, product.Quantity);
        nudMinimum.Value = Math.Min(nudMinimum.Maximum, product.MinimumQuantity);
        txtSupplier.Text = product.Supplier;
    }

    private void btnNewProduct_Click(object? sender, EventArgs e)
    {
        _selectedId = 0;
        dgvProducts.ClearSelection();
        txtSku.Clear();
        txtProductName.Clear();
        cmbCategory.SelectedIndex = 0;
        cmbUnit.SelectedIndex = 0;
        nudPrice.Value = 0;
        nudQuantity.Value = 0;
        nudMinimum.Value = 0;
        txtSupplier.Clear();
        txtSku.Focus();
        lblStatus.Text = "Новая карточка материала. Заполните поля и нажмите «Сохранить».";
    }

    private void btnSaveProduct_Click(object? sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtSku.Text) || string.IsNullOrWhiteSpace(txtProductName.Text))
        {
            MessageBox.Show("Заполните артикул и наименование.", "Проверка", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        if (cmbCategory.SelectedItem is null || cmbUnit.SelectedItem is null)
        {
            MessageBox.Show("Выберите категорию и единицу измерения.", "Проверка", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        var item = new Product
        {
            Id = _selectedId,
            Sku = txtSku.Text.Trim(),
            Name = txtProductName.Text.Trim(),
            Category = cmbCategory.SelectedItem.ToString()!,
            Unit = cmbUnit.SelectedItem.ToString()!,
            PriceKopecks = checked((long)(nudPrice.Value * 100m)),
            Quantity = (int)nudQuantity.Value,
            MinimumQuantity = (int)nudMinimum.Value,
            Supplier = txtSupplier.Text.Trim()
        };
        try
        {
            StoreDatabase.SaveProduct(item);
            btnNewProduct_Click(sender, EventArgs.Empty);
            RefreshProducts();
            lblStatus.Text = $"Сохранено: {item.Name}";
        }
        catch (SqliteException ex) when (ex.SqliteErrorCode == 19)
        {
            MessageBox.Show("Этот артикул уже используется. Укажите другой.", "Проверка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        catch (Exception ex)
        {
            ShowError(ex);
        }
    }

    private void btnRemoveProduct_Click(object? sender, EventArgs e)
    {
        if (_selectedId == 0)
        {
            MessageBox.Show("Сначала выберите товар в таблице.", "Удаление", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        if (MessageBox.Show("Удалить выбранный материал из базы?", "Подтвердите удаление",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        try
        {
            StoreDatabase.RemoveProduct(_selectedId);
            btnNewProduct_Click(sender, EventArgs.Empty);
            RefreshProducts();
            lblStatus.Text = "Материал удалён.";
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void btnImport_Click(object? sender, EventArgs e)
    {
        using var dialog = new OpenFileDialog { Filter = "CSV-файлы (*.csv)|*.csv|Все файлы (*.*)|*.*", Title = "Импортировать товары из CSV" };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            var items = CsvCatalog.Read(dialog.FileName);
            if (MessageBox.Show($"Найдено {items.Count} товаров. Совпадающие артикулы будут обновлены. Продолжить?",
                "Импорт", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            var count = StoreDatabase.ImportProducts(items);
            btnNewProduct_Click(sender, EventArgs.Empty);
            RefreshProducts();
            MessageBox.Show($"Успешно обработано {count} позиций.", "Импорт завершён", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void btnExport_Click(object? sender, EventArgs e)
    {
        using var dialog = new SaveFileDialog { Filter = "CSV-файлы (*.csv)|*.csv", FileName = "StroyMarket_Catalog.csv", Title = "Сохранить каталог" };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            CsvCatalog.Write(dialog.FileName, StoreDatabase.GetProducts());
            lblStatus.Text = "Каталог успешно выгружен в CSV.";
            MessageBox.Show("Каталог сохранён.", "Экспорт", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void btnBackup_Click(object? sender, EventArgs e)
    {
        using var dialog = new SaveFileDialog
        {
            Filter = "База данных (*.db)|*.db",
            FileName = $"StroyMarket_Backup_{DateTime.Now:yyyyMMdd_HHmm}.db",
            Title = "Резервная копия"
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            StoreDatabase.Backup(dialog.FileName);
            lblStatus.Text = "Резервная копия создана.";
            MessageBox.Show("Резервная копия базы данных сохранена.", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private void btnCustomersNav_Click(object? sender, EventArgs e)
    {
        Hide();
        try
        {
            using var customers = new Form3();
            customers.ShowDialog();
        }
        finally
        {
            Show();
            RefreshProducts();
        }
    }

    private void btnLogout_Click(object? sender, EventArgs e) => Close();

    private void ShowError(Exception exception)
    {
        MessageBox.Show(exception.Message, "Строй Маркет", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}
