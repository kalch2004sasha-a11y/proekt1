using System.Globalization;
using System.Security.Cryptography;
using Microsoft.Data.Sqlite;

namespace StroyMarket;

internal static class StoreDatabase
{
    private static readonly string Folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "StroyMarket");
    private static readonly string DatabaseFile = Path.Combine(Folder, "stroy_market_redesign.db");

    private static SqliteConnection Open()
    {
        var connection = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = DatabaseFile }.ToString());
        connection.Open();
        using var pragma = connection.CreateCommand();
        pragma.CommandText = "PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;";
        pragma.ExecuteNonQuery();
        return connection;
    }

    public static void Initialize()
    {
        Directory.CreateDirectory(Folder);
        var newDatabase = !File.Exists(DatabaseFile);
        using var connection = Open();
        using var command = connection.CreateCommand();
        command.CommandText = """
            CREATE TABLE IF NOT EXISTS Users (
                Id INTEGER PRIMARY KEY AUTOINCREMENT,
                Login TEXT NOT NULL UNIQUE,
                PasswordSalt BLOB NOT NULL,
                PasswordHash BLOB NOT NULL
            );
            CREATE TABLE IF NOT EXISTS Products (
                Id INTEGER PRIMARY KEY AUTOINCREMENT,
                Sku TEXT NOT NULL UNIQUE,
                Name TEXT NOT NULL,
                Category TEXT NOT NULL,
                Unit TEXT NOT NULL,
                PriceKopecks INTEGER NOT NULL CHECK (PriceKopecks >= 0),
                Quantity INTEGER NOT NULL CHECK (Quantity >= 0),
                MinimumQuantity INTEGER NOT NULL CHECK (MinimumQuantity >= 0),
                Supplier TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS Customers (
                Id INTEGER PRIMARY KEY AUTOINCREMENT,
                LastName TEXT NOT NULL,
                FirstName TEXT NOT NULL,
                MiddleName TEXT NOT NULL DEFAULT '',
                Phone TEXT NOT NULL,
                Email TEXT NOT NULL DEFAULT '',
                Type TEXT NOT NULL DEFAULT 'Розничный',
                Address TEXT NOT NULL DEFAULT '',
                Discount INTEGER NOT NULL DEFAULT 0 CHECK (Discount BETWEEN 0 AND 100),
                Notes TEXT NOT NULL DEFAULT ''
            );
            """;
        command.ExecuteNonQuery();

        var passwordSalt = RandomNumberGenerator.GetBytes(16);
        var passwordHash = Rfc2898DeriveBytes.Pbkdf2("Sasha1", passwordSalt, 120000, HashAlgorithmName.SHA256, 32);
        using (var account = connection.CreateCommand())
        {
            account.CommandText = """
                INSERT INTO Users(Login, PasswordSalt, PasswordHash) VALUES($login, $salt, $hash)
                ON CONFLICT(Login) DO UPDATE SET
                    PasswordSalt=excluded.PasswordSalt, PasswordHash=excluded.PasswordHash
                """;
            account.Parameters.AddWithValue("$login", "Sasha");
            account.Parameters.AddWithValue("$salt", passwordSalt);
            account.Parameters.AddWithValue("$hash", passwordHash);
            account.ExecuteNonQuery();
        }
        using (var removeOtherAccounts = connection.CreateCommand())
        {
            removeOtherAccounts.CommandText = "DELETE FROM Users WHERE Login <> $login";
            removeOtherAccounts.Parameters.AddWithValue("$login", "Sasha");
            removeOtherAccounts.ExecuteNonQuery();
        }

        using var products = connection.CreateCommand();
        products.CommandText = "SELECT COUNT(*) FROM Products";
        if (newDatabase && (long)(products.ExecuteScalar() ?? 0L) == 0)
        {
            foreach (var product in DemoProducts())
                SaveProductInternal(connection, null, product);
        }

        using var customers = connection.CreateCommand();
        customers.CommandText = "SELECT COUNT(*) FROM Customers";
        if (newDatabase && (long)(customers.ExecuteScalar() ?? 0L) == 0)
        {
            SaveCustomerInternal(connection, null, new Customer { LastName = "Соколов", FirstName = "Андрей", Phone = "+7 (900) 000-00-01", Email = "demo1@example.com", Type = "Мастер", Address = "Демонстрационный адрес", Discount = 5 });
            SaveCustomerInternal(connection, null, new Customer { LastName = "Миронова", FirstName = "Елена", Phone = "+7 (900) 000-00-02", Email = "demo2@example.com", Type = "Розничный", Discount = 0 });
        }
    }

    private static IEnumerable<Product> DemoProducts()
    {
        yield return new Product { Sku = "SM-101", Name = "Цемент М500, 50 кг", Category = "Сухие смеси", Unit = "меш.", PriceKopecks = 64500, Quantity = 48, MinimumQuantity = 15, Supplier = "РегионСтрой" };
        yield return new Product { Sku = "SM-102", Name = "Шпаклёвка финишная, 20 кг", Category = "Сухие смеси", Unit = "меш.", PriceKopecks = 87000, Quantity = 12, MinimumQuantity = 15, Supplier = "РегионСтрой" };
        yield return new Product { Sku = "SM-103", Name = "Грунтовка глубокого проникновения, 10 л", Category = "Лакокрасочные материалы", Unit = "шт.", PriceKopecks = 119000, Quantity = 31, MinimumQuantity = 8, Supplier = "ПокрытиеПлюс" };
        yield return new Product { Sku = "SM-104", Name = "Утеплитель минеральный, 5 м²", Category = "Изоляция", Unit = "упак.", PriceKopecks = 219000, Quantity = 9, MinimumQuantity = 10, Supplier = "ТеплоДом" };
        yield return new Product { Sku = "SM-105", Name = "Саморезы 4,2 × 70 мм, 200 шт.", Category = "Крепёж", Unit = "упак.", PriceKopecks = 34900, Quantity = 72, MinimumQuantity = 20, Supplier = "КрепёжСнаб" };
        yield return new Product { Sku = "SM-106", Name = "Валик малярный 250 мм", Category = "Инструменты", Unit = "шт.", PriceKopecks = 42000, Quantity = 7, MinimumQuantity = 10, Supplier = "МастерИнструмент" };
    }

    public static bool VerifyCredentials(string login, string password)
    {
        using var connection = Open();
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT PasswordSalt, PasswordHash FROM Users WHERE Login = $login";
        command.Parameters.AddWithValue("$login", login.Trim());
        using var reader = command.ExecuteReader();
        if (!reader.Read()) return false;
        var salt = (byte[])reader[0];
        var expected = (byte[])reader[1];
        var received = Rfc2898DeriveBytes.Pbkdf2(password, salt, 120000, HashAlgorithmName.SHA256, expected.Length);
        return CryptographicOperations.FixedTimeEquals(expected, received);
    }

    public static List<Product> GetProducts()
    {
        var result = new List<Product>();
        using var connection = Open();
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT Id, Sku, Name, Category, Unit, PriceKopecks, Quantity, MinimumQuantity, Supplier FROM Products ORDER BY Name COLLATE NOCASE";
        using var reader = command.ExecuteReader();
        while (reader.Read())
        {
            result.Add(new Product
            {
                Id = reader.GetInt64(0), Sku = reader.GetString(1), Name = reader.GetString(2),
                Category = reader.GetString(3), Unit = reader.GetString(4), PriceKopecks = reader.GetInt64(5),
                Quantity = reader.GetInt32(6), MinimumQuantity = reader.GetInt32(7), Supplier = reader.GetString(8)
            });
        }
        return result;
    }

    public static void SaveProduct(Product product)
    {
        using var connection = Open();
        SaveProductInternal(connection, null, product);
    }

    private static void SaveProductInternal(SqliteConnection connection, SqliteTransaction? transaction, Product product)
    {
        using var command = connection.CreateCommand();
        command.Transaction = transaction;
        command.CommandText = product.Id == 0
            ? "INSERT INTO Products (Sku, Name, Category, Unit, PriceKopecks, Quantity, MinimumQuantity, Supplier) VALUES ($sku, $name, $category, $unit, $price, $quantity, $minimum, $supplier)"
            : "UPDATE Products SET Sku=$sku, Name=$name, Category=$category, Unit=$unit, PriceKopecks=$price, Quantity=$quantity, MinimumQuantity=$minimum, Supplier=$supplier WHERE Id=$id";
        command.Parameters.AddWithValue("$sku", product.Sku.Trim());
        command.Parameters.AddWithValue("$name", product.Name.Trim());
        command.Parameters.AddWithValue("$category", product.Category);
        command.Parameters.AddWithValue("$unit", product.Unit);
        command.Parameters.AddWithValue("$price", product.PriceKopecks);
        command.Parameters.AddWithValue("$quantity", product.Quantity);
        command.Parameters.AddWithValue("$minimum", product.MinimumQuantity);
        command.Parameters.AddWithValue("$supplier", product.Supplier.Trim());
        if (product.Id != 0) command.Parameters.AddWithValue("$id", product.Id);
        command.ExecuteNonQuery();
    }

    public static void RemoveProduct(long id)
    {
        using var connection = Open();
        using var command = connection.CreateCommand();
        command.CommandText = "DELETE FROM Products WHERE Id = $id";
        command.Parameters.AddWithValue("$id", id);
        command.ExecuteNonQuery();
    }

    public static int ImportProducts(IEnumerable<Product> entries)
    {
        using var connection = Open();
        using var transaction = connection.BeginTransaction();
        var total = 0;
        foreach (var entry in entries)
        {
            using var command = connection.CreateCommand();
            command.Transaction = transaction;
            command.CommandText = """
                INSERT INTO Products (Sku, Name, Category, Unit, PriceKopecks, Quantity, MinimumQuantity, Supplier)
                VALUES ($sku, $name, $category, $unit, $price, $quantity, $minimum, $supplier)
                ON CONFLICT(Sku) DO UPDATE SET
                Name=excluded.Name, Category=excluded.Category, Unit=excluded.Unit,
                PriceKopecks=excluded.PriceKopecks, Quantity=excluded.Quantity,
                MinimumQuantity=excluded.MinimumQuantity, Supplier=excluded.Supplier
                """;
            command.Parameters.AddWithValue("$sku", entry.Sku);
            command.Parameters.AddWithValue("$name", entry.Name);
            command.Parameters.AddWithValue("$category", entry.Category);
            command.Parameters.AddWithValue("$unit", entry.Unit);
            command.Parameters.AddWithValue("$price", entry.PriceKopecks);
            command.Parameters.AddWithValue("$quantity", entry.Quantity);
            command.Parameters.AddWithValue("$minimum", entry.MinimumQuantity);
            command.Parameters.AddWithValue("$supplier", entry.Supplier);
            command.ExecuteNonQuery();
            total++;
        }
        transaction.Commit();
        return total;
    }

    public static List<Customer> GetCustomers()
    {
        var result = new List<Customer>();
        using var connection = Open();
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT Id, LastName, FirstName, MiddleName, Phone, Email, Type, Address, Discount, Notes FROM Customers ORDER BY LastName, FirstName";
        using var reader = command.ExecuteReader();
        while (reader.Read())
        {
            result.Add(new Customer
            {
                Id = reader.GetInt64(0), LastName = reader.GetString(1), FirstName = reader.GetString(2),
                MiddleName = reader.GetString(3), Phone = reader.GetString(4), Email = reader.GetString(5),
                Type = reader.GetString(6), Address = reader.GetString(7), Discount = reader.GetInt32(8),
                Notes = reader.GetString(9)
            });
        }
        return result;
    }

    public static void SaveCustomer(Customer customer)
    {
        using var connection = Open();
        SaveCustomerInternal(connection, null, customer);
    }

    private static void SaveCustomerInternal(SqliteConnection connection, SqliteTransaction? transaction, Customer customer)
    {
        using var command = connection.CreateCommand();
        command.Transaction = transaction;
        command.CommandText = customer.Id == 0
            ? "INSERT INTO Customers (LastName, FirstName, MiddleName, Phone, Email, Type, Address, Discount, Notes) VALUES ($last, $first, $middle, $phone, $email, $type, $address, $discount, $notes)"
            : "UPDATE Customers SET LastName=$last, FirstName=$first, MiddleName=$middle, Phone=$phone, Email=$email, Type=$type, Address=$address, Discount=$discount, Notes=$notes WHERE Id=$id";
        command.Parameters.AddWithValue("$last", customer.LastName.Trim());
        command.Parameters.AddWithValue("$first", customer.FirstName.Trim());
        command.Parameters.AddWithValue("$middle", customer.MiddleName.Trim());
        command.Parameters.AddWithValue("$phone", customer.Phone.Trim());
        command.Parameters.AddWithValue("$email", customer.Email.Trim());
        command.Parameters.AddWithValue("$type", customer.Type);
        command.Parameters.AddWithValue("$address", customer.Address.Trim());
        command.Parameters.AddWithValue("$discount", customer.Discount);
        command.Parameters.AddWithValue("$notes", customer.Notes.Trim());
        if (customer.Id != 0) command.Parameters.AddWithValue("$id", customer.Id);
        command.ExecuteNonQuery();
    }

    public static void RemoveCustomer(long id)
    {
        using var connection = Open();
        using var command = connection.CreateCommand();
        command.CommandText = "DELETE FROM Customers WHERE Id = $id";
        command.Parameters.AddWithValue("$id", id);
        command.ExecuteNonQuery();
    }

    public static void Backup(string destination)
    {
        var staging = Path.Combine(Folder, $"backup_{Guid.NewGuid():N}.db");
        try
        {
            using (var original = Open())
            using (var copy = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = staging }.ToString()))
            {
                copy.Open();
                original.BackupDatabase(copy);
            }
            File.Copy(staging, destination, true);
        }
        finally
        {
            if (File.Exists(staging)) File.Delete(staging);
        }
    }
}
